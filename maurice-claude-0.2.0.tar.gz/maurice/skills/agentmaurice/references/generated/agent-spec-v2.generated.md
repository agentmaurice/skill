# Agent Spec V2 — contrats embarqués

> Généré par `tools/contract_tool.py`. Ne pas modifier à la main.

Bundle SHA-256 : `781642b0dd961739c8051c117259544e0f410b4cdd70f7555d3551c956c2d0c9`

Charge le schéma ou l'exemple exact avec `maurice spec schema <contrat>` et
`maurice spec example <contrat>`. Les copies ci-dessous sont validées à chaque génération.

| Contrat | Identifiant | Exemple validé |
|---|---|---|
| `project` | `agentmaurice.project/v2` | [`examples/project.json`](examples/project.json) (`1a64d1c76cd0878a56e37be2112491fac6185193a33817e5583234952d9c45f7`) |
| `environment` | `agentmaurice.environment/v2` | [`examples/environment.json`](examples/environment.json) (`6249b1dec781406f897453b28c5f0ff654cc70db5c1f54f2681688cc622d7285`) |
| `lock` | `agentmaurice.lock/v2` | [`examples/lock.json`](examples/lock.json) (`8dc246ba536d786813134e8f0b0c6aef19e09b38f3ae6187a6221363a1b6876a`) |
| `agent-spec` | `agentmaurice.agent_spec/v2` | [`examples/agent-spec.json`](examples/agent-spec.json) (`1f6a8a5b2d501f49a31a681b46040aff9f3c91c4cb14291fb4446571f140cc70`) |
| `workflow` | `agentmaurice.workflow/v2` | [`examples/workflow.json`](examples/workflow.json) (`8391ce2031a255c9db095cf8843b0a6ebc3bd969e0de807c8faaae48130066e1`) |
| `miniapp` | `agentmaurice.miniapp/v2` | [`examples/miniapp.json`](examples/miniapp.json) (`62faa6dcef35553f5cc0013e037b007b1e78b937721aa28af23182e48ad78b37`) |
| `test-plan` | `agentmaurice.test_plan/v2` | [`examples/test-plan.json`](examples/test-plan.json) (`bde2a560c4ad6986b6bddfac4e6ca83945b83f2472a304d9e77c5f3167e50844`) |
| `bootstrap` | `agentmaurice.bootstrap/v2` | [`examples/bootstrap.json`](examples/bootstrap.json) (`0140826c525bf0b6578c3531eace034a99a13c3cce8b8a2456bada07d79017d3`) |
| `cli-error` | `agentmaurice.cli_error/v2` | [`examples/cli-error.json`](examples/cli-error.json) (`fc5e4aece83dc312d22bc7eecd9b4f08e44131512631b410e87f38358d7fe11e`) |

Exemple complet : [Prospects bornés](bounded-prospects/README.md).
Actions Workflow : tool_call, code_execution, llm_call, workflow_call, decision, for_each et question.
question : choix, score ou noul calibré en un appel System One ; state court, critères discriminants, min_confidence avant write ; métadonnées sous output_key._meta. Classifier avec question puis decision/input, jamais code_execution + callTool("llm_chat_completion").
decision : selector.mode=input pour une valeur structurée, ou llm avec llm_prompt et llm_model portable slug:model ; child_input transmet un objet au fils.
Le sélecteur LLM utilise une température zéro et un enum fermé ; réponse invalide ou confiance sous min_confidence => fallback. Une erreur provider reste un échec visible.
confidence_kind distingue self_reported et none ; ne jamais présenter une confiance JSON auto-déclarée comme calibrée. Doctor avertit lorsqu'un seuil porte sur cette confiance.
for_each : liste structurée, max_items de 1 à 100, exécution séquentielle sans troncature.
output est requis avec output_schema ; llm_response_schema est requis avec le format JSON.
Ne pas contourner decision ou for_each par une boucle JavaScript callRecipe.
Le schéma embarqué est normatif. La référence Skill ne doit jamais inventer un champ
absent du schéma ni contourner `maurice spec check`.
Chaque objet `capabilities[]` de `agent-spec.json` doit désigner explicitement son
Workflow local avec `workflow_id`; aucune résolution par nom ou alias n'est autorisée.
`allowed_agent_ids` accorde cette capacité aux seuls Agents listés (1 à 32 identifiants uniques de la même organisation). Absent : privé. Aucun wildcard. Le plan et chaque appel contrôlent les permissions courantes ; la révocation reste effective après compilation.
